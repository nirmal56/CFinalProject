#include<string.h>
#include<stdio.h>
#include<stdlib.h>
char c;
size_t len = 32;
struct emailSeg{
	char *fromAdd;
	char* toAdd;
	char* sub;
	char body[1000];
	struct emailSeg *p;
}emails[5];

void main(){
	FILE *fp;
	char fname[100];
	for(int i=0;i<5;i++){
		snprintf(fname, 7, "e%d.txt", (i+1));
		fp = fopen(fname,"r");
		getline(&emails[i].fromAdd, &len, fp);
		getline(&emails[i].toAdd, &len, fp);
		getline(&emails[i].sub, &len, fp);
		emails[i].p=&fp;
		int index = 0;
		do {
        		c = fgetc(fp);
 			emails[i].body[index++] = c;
   		} while (c != EOF);
	}
	for(int i = 0 ; i < 5 ; i ++){
		printf("Email No : %d\n", i+1);
		printf("From : %s",emails[i].fromAdd);
		printf("To : %s",emails[i].toAdd);
		printf("Subject : %s",emails[i].sub);
		printf("Body : %s",emails[i].body);
		printf("pointer: %p \n\n\n",emails[i].p);
	}
	free(fp);	
}
