#include<stdio.h>
#include<stdbool.h>

double M_PI=3.14159265;

void cirCir(double a);
void cirArea(double a);
void sphVol(double a);

void (*p[3]) (double x)={cirCir,cirArea,sphVol};

double radius;
int choice;
bool flag=true;

void main(){
	while(flag){
		printf("press 1 for circle's circumference\npress 2 for circle's Area\npress 3 for sphere's volume:\npress -1 to exit:\n");
		scanf("%d",&choice);
				
		switch (choice){
			case 1:
				printf("enter radius:");
				scanf("%lf",&radius);
				(*p[0])(radius);
				break;
			case 2:
				printf("enter radius:");
				scanf("%lf",&radius);
				(*p[1])(radius);
				break;
			case 3:
				printf("enter radius:");
				scanf("%lf",&radius);
				(*p[2])(radius);
				break;
			case -1:
				flag=false;
				break;
		}
	}
}

void cirCir(double a){
	double ans;
	ans=2*M_PI*a;
	printf("radius:%lf\t",a);
	printf("Circumference of Circle:%lf\n",ans);
}

void cirArea(double a){
	double ans;
	ans=M_PI*a*a;
	printf("radius:%lf\t",a);
	printf("Area of circle:%lf\n",ans);
}

void sphVol(double a){
	double ans;
	double multiplier ;
	ans=((4.0/3.0)*M_PI*(a*a*a));
	printf("radius:%lf\t",a);
	printf("Volume of sphere:%lf\n",ans);
}
