#include <stdio.h>
#include <string.h>
#include <stdbool.h>
char *itoa(int val, int base)
{

    static char buf[32] = {0};

    int i = 30;

    for (; val && i; --i, val /= base)

        buf[i] = "0123456789abcdef"[val % base];

    return &buf[i + 1];
}

struct employee
{
    char oindex[5];
    char id[100];
    char fname[100];
    char lname[100];
    char pNum[100];
    char city[100];
    char parknum[100];
    char spouseName[100];
    char all[1000];
} temp;
char *getValue(int index, int key);
struct employee database[100];
int cindex = 0;
size_t size;
FILE *fp;
void sort(int key)
{
    for (int i = 0; i < 6; i++)
    {
        for (int j = i + 1; j < 6; j++)
        {
            if (strcmp(getValue(i, key), getValue(j, key)) > 0)
            {
                temp = database[i];
                database[i] = database[j];
                database[j] = temp;
            }
        }
    }
}
char *getValue(int index, int key)
{
    switch (key)
    {
    case 0:
        return database[index].oindex;
    case 1:
        return database[index].id;
    case 2:
        return database[index].fname;
    case 3:
        return database[index].lname;
    case 4:
        return database[index].pNum;
    case 5:
        return database[index].city;
    case 6:
        return database[index].parknum;
    case 7:
        return database[index].spouseName;
    case 8:
        return database[index].all;
    }
}
bool parseLine()
{
    char *emp;
    if (getline(&emp, &size, fp) > 1)
    {
        strcpy(database[cindex].oindex, itoa(cindex + 1, 10));
        strcpy(database[cindex].all, emp);
        char *token;
        strcpy(database[cindex].id, strtok(emp, " "));
        strcpy(database[cindex].fname, strtok(NULL, " "));
        strcpy(database[cindex].lname, strtok(NULL, " "));
        strcpy(database[cindex].pNum, strtok(NULL, " "));
        strcpy(database[cindex].city, strtok(NULL, " "));
        strcpy(database[cindex].parknum, strtok(NULL, " "));
        strcpy(database[cindex++].spouseName, strtok(NULL, "\n"));
        return true;
    }
    return false;
}
bool check(char * toc){
    if(strcmp(toc,"-1") == 0 || strcmp(toc,"na") == 0){
        return false;
    }

    printf("%s\n", toc);
    return true;
}
int main()
{
    fp = fopen("emp.txt", "r");
    while (parseLine())
        ;
    sort(5);
    int n, cases, q;
    scanf("%d", &n);
    scanf("%d", &cases);
    for (int i = 0; i < cases; i++)
    {

        scanf("%d", &q);
        sort(q);
        for (int i = 0; i < n; i++)
        {
            if(check(getValue(i,q))){
                printf("%s\n", getValue(i, 8));
            }
            else{
                // break;
            }
        }
        printf("-----\n");
        sort(0);
    }

    return 0;
}